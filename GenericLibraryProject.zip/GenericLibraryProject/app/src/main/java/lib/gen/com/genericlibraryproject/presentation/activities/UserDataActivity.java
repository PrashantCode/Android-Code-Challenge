package lib.gen.com.genericlibraryproject.presentation.activities;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.HashMap;

import lib.gen.com.genericlibrary.controller.GetAndParseData;
import lib.gen.com.genericlibraryproject.R;
import lib.gen.com.genericlibraryproject.presentation.adapter.UserDataAdapter;

import static lib.gen.com.genericlibraryproject.R.layout.user_data_list_row;

/**
 * Launcher Activity
 */
public class UserDataActivity extends AppCompatActivity {

    private static final String TAG = UserDataActivity.class.getSimpleName();

    // URL to get JSON
    private static String URL = "http://private-d847e-demoresponse.apiary-mock.com/questions";
    ArrayList<HashMap<String,String>> mUserDataList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_data);

        // Entry point for the library to get the user data list
        mUserDataList = callLibrary();
        //display user data
        displayData(mUserDataList);

    }

    /**
     * Calling one exposed library method
     * @return list
     */
    private ArrayList<HashMap<String,String>> callLibrary() {

        GetAndParseData getAndParseData = new GetAndParseData();
        return getAndParseData.startProcessing(URL);
    }


    /**
     * Setting data in listview
     * @param userDataList
     */
    private void displayData(ArrayList<HashMap<String,String>> userDataList){

        ListView userDataListView = (ListView) findViewById(R.id.user_data_listView);
        // instantiate the custom list adapter
        UserDataAdapter userDataAdapter = new UserDataAdapter(this, user_data_list_row, userDataList);
        userDataListView.setAdapter(userDataAdapter);

    }

}
