package lib.gen.com.genericlibraryproject.presentation.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;

import lib.gen.com.genericlibraryproject.presentation.activities.ImageActivity;
import lib.gen.com.genericlibraryproject.R;

/**
 * Class to populate user data in listView
 */
public class UserDataAdapter extends BaseAdapter {

    ArrayList<HashMap<String, String>> mUserDataList;
    private Context mContext;
    private LayoutInflater mInflater;
    private int mResource;

    public UserDataAdapter(Context context, int resource, ArrayList<HashMap<String, String>> userDataList) {
        this.mUserDataList = userDataList;
        this.mContext = context;
        this.mInflater = LayoutInflater.from(context);
        this.mResource = resource;
    }

    @Override
    public int getCount() {
        if (mUserDataList != null) {
            return mUserDataList.size();
        }
        return 0;
    }

    @Override
    public Object getItem(int position) {
        return mUserDataList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        if (convertView == null) {
            convertView = mInflater.inflate(mResource, parent, false);
            holder = new ViewHolder();
            holder.name = (TextView) convertView.findViewById(R.id.name);
            holder.country = (TextView) convertView.findViewById(R.id.country);
            holder.text = (TextView) convertView.findViewById(R.id.text);
            holder.created = (TextView) convertView.findViewById(R.id.created);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }
        // need to define String in constant and use
        holder.name.setText(mUserDataList.get(position).get("name"));
        holder.country.setText(mUserDataList.get(position).get("country"));

        if (mUserDataList.get(position).get("url")!= null){
            holder.text.setText(mUserDataList.get(position).get("url"));
            holder.text.setClickable(true);
            holder.text.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    loadWebView(position);
                }
            });
        }else if (mUserDataList.get(position).get("text")!= null){
            holder.text.setText(mUserDataList.get(position).get("text"));
            holder.text.setClickable(false);
        }

        holder.created.setText(mUserDataList.get(position).get("created"));
        return convertView;
    }

    private void loadWebView(int position) {
        Intent intent = new Intent(mContext,ImageActivity.class);
        intent.putExtra("url",mUserDataList.get(position).get("url"));
        mContext.startActivity(intent);
    }

    /**
     * To hold views of list view row
     */
    static class ViewHolder {
        TextView name;
        TextView country;
        TextView text;
        TextView created;
    }

}
