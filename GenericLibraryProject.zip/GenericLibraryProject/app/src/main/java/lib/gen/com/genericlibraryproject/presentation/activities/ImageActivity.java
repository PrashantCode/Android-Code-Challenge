package lib.gen.com.genericlibraryproject.presentation.activities;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.WebView;

import lib.gen.com.genericlibraryproject.R;

public class ImageActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_image);

        getUrlAndLoad();
    }

    /**
     * Loading image in viewView
     */
    private void getUrlAndLoad(){
        String url = getIntent().getStringExtra("url");
        WebView webView = (WebView) findViewById(R.id.webView);
        webView.loadUrl(url);
    }

    //need to fix back functionality by overriding onKeyDown method of webview
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }
}
