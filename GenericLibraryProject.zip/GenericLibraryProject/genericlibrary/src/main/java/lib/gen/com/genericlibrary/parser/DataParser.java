package lib.gen.com.genericlibrary.parser;

import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;


/**
 * Parsing Data
 */
public class DataParser {

    private static final String TAG = DataParser.class.getSimpleName();
    ArrayList<HashMap<String, String>> userDataList = new ArrayList<>();

    /**
     * Converting string to jsonArray
     *
     * @param result
     */
    public ArrayList<HashMap<String, String>> getDataToParse(String result) {
        JSONArray jsonArray = null;
        if (result != null) {
            try {
                jsonArray = new JSONArray(result);
            } catch (final JSONException e) {
                Log.e(TAG, "JSONException: " + e.getMessage());
            }
            return parseData(jsonArray);
        } else {
            return null;
        }
    }

    /**
     * parsing data
     *
     * @param jsonArray
     */
    private ArrayList<HashMap<String, String>> parseData(JSONArray jsonArray) {
        for (int i = 0; i < jsonArray.length(); i++) {
            JSONObject jsonObject = jsonArray.optJSONObject(i);

            String created = jsonObject.optString(JsonMap.created);

            //not zero, some value, means created
            if (!created.equalsIgnoreCase(JsonMap.zero)) {

                String type = jsonObject.optString(JsonMap.type);

                JSONObject dataJsonObject = jsonObject.optJSONObject(JsonMap.data);

                String url = null;
                String text = null;
                if (type.equalsIgnoreCase(JsonMap.img) && dataJsonObject != null) {
                    url = dataJsonObject.optString(JsonMap.url);
                } else if (type.equalsIgnoreCase(JsonMap.text) && dataJsonObject != null) {
                    text = dataJsonObject.optString(JsonMap.text);
                }

                JSONObject userJsonObject = jsonObject.optJSONObject(JsonMap.user);

                String name = userJsonObject.optString(JsonMap.name);
                String country = userJsonObject.optString(JsonMap.country);

                // Hashmap to hold userData
                HashMap<String, String> userData = new HashMap<>();

                //adding data to hashmap
                userData.put(JsonMap.created, created);
                userData.put(JsonMap.type, type);
                if (type.equalsIgnoreCase(JsonMap.img)) {
                    userData.put(JsonMap.url, url);
                } else if (type.equalsIgnoreCase(JsonMap.text)) {
                    userData.put(JsonMap.text, text);
                }
                userData.put(JsonMap.name, name);
                userData.put(JsonMap.country, country);

                // Adding all userData to list
                userDataList.add(userData);
            }
        }
        return userDataList;
    }

    private interface JsonMap {

        String created = "created";
        String zero = "0";
        String type = "type";
        String data = "data";
        String img = "img";
        String url = "url";
        String text = "text";
        String user = "user";
        String name = "name";
        String country = "country";

    }

}
