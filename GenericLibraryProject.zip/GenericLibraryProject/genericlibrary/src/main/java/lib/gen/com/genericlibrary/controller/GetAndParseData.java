package lib.gen.com.genericlibrary.controller;

import android.util.Log;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.concurrent.ExecutionException;

import lib.gen.com.genericlibrary.http.Task;
import lib.gen.com.genericlibrary.parser.DataParser;


/**
 * Entry point class for the project that will
 * use this library to do network operation and will get data.
 * We are exposing only one public method.
 *
 * This class will also be like controller between http calls and data parsing
 */
public class GetAndParseData {

    private static final String TAG = GetAndParseData.class.getSimpleName();
    String result;

    /**
     * Entry for library
     * Only this method will be visible to the outside
     * @param url
     */
    public ArrayList<HashMap<String,String>> startProcessing(String url){

        //Instantiate new instance of task class
        Task task = new Task();
        //Perform the doInBackground method, passing in our url
        try {
            result = task.execute(url).get();
        } catch (InterruptedException e) {
            Log.e(TAG, "InterruptedException: " + e.getMessage());
        } catch (ExecutionException e) {
            Log.e(TAG, "ExecutionException: " + e.getMessage());
        }
        if (result != null) {
             return sendDataToParse(result);
        }else {
            Log.e(TAG,"no data to parse");
            return null;
        }
    }

    /**
     * Sending data to parser class
     * @param result
     */
    private ArrayList<HashMap<String,String>> sendDataToParse(String result){

        //Instantiate new instance of parser class
        DataParser dataParser = new DataParser();
        return dataParser.getDataToParse(result);
    }
}
