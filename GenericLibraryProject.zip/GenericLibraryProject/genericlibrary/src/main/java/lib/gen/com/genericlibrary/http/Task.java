package lib.gen.com.genericlibrary.http;

import android.os.AsyncTask;


/**
 * Aysnctask to get overriden methods
 */
public class Task extends AsyncTask<String, Void, String> {

    @Override
    protected String doInBackground(String... params) {

        HttpUtility httpUtility = new HttpUtility();
        // Making a request to url and getting response
        String jsonStr = httpUtility.httpRequestCall(params[0]);
        return jsonStr;
    }

    @Override
    protected void onPostExecute(String result) {
        super.onPostExecute(result);
    }
}

// The idea is to avoid creating threads of our own, for calling webservice
// We are using doInBackground method that not runs on UI thread.
// if needed, we can remove this class and can directly call Utility class on Background thread.